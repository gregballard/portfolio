﻿//----------- CBrickCollection class
function CBrickCollection() {
    this.rowWidth = 4;
    this.arrayBricks = new Array();
    this.loadBricks();
       
}

CBrickCollection.prototype.loadBricks = function () {

    var rowY = 25;
    var objBrick = new CBar();

    // top row
    this.loadRow(40, rowY, "red");
    rowY = rowY + 5 + objBrick.height;

    this.loadRow(40, rowY, "blue");
    rowY = rowY + 5 + objBrick.height;

    this.loadRow(40, rowY, "green");
    rowY = rowY + 5 + objBrick.height;

    this.loadRow(40, rowY, "orange");

};

CBrickCollection.prototype.loadRow = function (x, y, color) {
    objBrick = new CBar();

    var nBrickCount;
    nBrickCount = this.arrayBricks.length;  

    this.arrayBricks[nBrickCount++] = objBrick.createBar(x, y, color);   

    for (var i = 1; i < this.rowWidth ; i++) {
      this.arrayBricks[nBrickCount] = objBrick.createBar(this.arrayBricks[nBrickCount++ - 1].x + 5 + objBrick.width, y, color);
    }
    
};

CBrickCollection.prototype.DetectCollision = function (objBall) {

    var bDetected = false;

    for (i = this.arrayBricks.length - 1; i >= 0; i--) {
        if (this.arrayBricks[i].DetectCollision(objBall)) {
            bDetected = true;
            this.arrayBricks[i].ClearBar();
            this.arrayBricks.splice(i, 1);
            sndGlassBreak.play();
        }
    }

    return bDetected;
};

CBrickCollection.prototype.draw = function() {
    for (i = 0; i < this.arrayBricks.length; i++) {
        this.arrayBricks[i].DrawBar();
    }
};

//----------- end CBrickCollection class