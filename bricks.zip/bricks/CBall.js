﻿// -------- Ball class
function CBall() {        
    this.nTop = 0;
    this.nBottom = 0;
    this.nRightSide = 0;
    this.nLeftSide = 0;
    this.width = 15;
    this.height = 15;

    this.setToStart();
}

CBall.prototype = new CBar;            // Hook up CBar into CBall's prototype chain
CBall.prototype.constructor = CBall;

CBall.prototype.MoveBall = function () {
    this.x = this.x + (1 * this.nRightDir);
    this.y = this.y + (1 * this.nDownDir);

    this.CalcBounds();
};

CBall.prototype.setToStart = function () {
    this.nRightDir = 1;
    this.nDownDir = 1;
    this.x = 0;
    this.y = 85;
    this.CalcBounds();
};
//-------- end Ball class