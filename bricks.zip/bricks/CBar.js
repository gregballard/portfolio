﻿//-------- Bar class
function CBar() {
    this.width = 75;
    this.height = 15;
    this.x = Math.floor((nRight / 2) - (this.width / 2));
    this.y = nBottom - this.height - 15;
    this.nBottom = 0;
    this.nTop = 0;
    this.nRightSide = 0;
    this.nLeftSide = 0;
    this.CalcBounds();
    this.Color = "black";

};

CBar.prototype = new CSprite;            // Hook up CSprite into CBar's prototype chain
CBar.prototype.constructor = CBar;

CBar.prototype.createBar = function (x, y, color) {

    objBar = new CBar();

    objBar.x = x;
    objBar.y = y;
    objBar.Color = color;

    objBar.CalcBounds();

    return objBar;

}; 

CBar.prototype.CalcTop = function () {
    this.nTop = this.y;
};

CBar.prototype.CalcBottom = function () {
    this.nBottom = this.y + this.height;
};

CBar.prototype.CalcLeftSide = function () {
    this.nLeftSide = this.x;
};

CBar.prototype.CalcRightSide = function () {
    this.nRightSide = this.x + this.width;
};

CBar.prototype.CalcBounds = function () {
    this.CalcLeftSide();
    this.CalcRightSide();
    this.CalcTop();
    this.CalcBottom();
};

CBar.prototype.DrawBar = function () {

    oldStyle = context.fillStyle;
    context.fillStyle = this.Color;
    context.fillRect(this.x, this.y, this.width, this.height);
    context.fillStyle = oldStyle;
};

CBar.prototype.ClearBar = function () {
    context.clearRect(this.x, this.y, this.width, this.height);
};

CBar.prototype.MoveLeft = function () {
    if (this.x > 0) {
        this.ClearBar();
        this.x = this.x - 2;
        this.CalcBounds();
        this.DrawBar();
    }
}

CBar.prototype.MoveRight = function () {
    if (this.x + this.width < nRight) {
        this.ClearBar();
        this.x = this.x + 2;
        this.CalcBounds();
        this.DrawBar();
    }
}

CBar.prototype.DetectCollision = function (xobjBar) {

    bReturn = false;

    // collide with top            
    if (xobjBar.nDownDir == 1 && xobjBar.nBottom == this.nTop && xobjBar.nRightSide >= this.nLeftSide && xobjBar.nLeftSide <= this.nRightSide) {
        xobjBar.nDownDir = -1;
        bReturn = true;
    }
    
    // else collide with bottom
    else if (xobjBar.nDownDir == -1 && xobjBar.nTop == this.nBottom && xobjBar.nRightSide >= this.nLeftSide && xobjBar.nLeftSide <= this.nRightSide) {
        xobjBar.nDownDir = 1;
        bReturn = true;
    }
            
    // collide with sides
    // collide with left side
    else if (xobjBar.nRightDir == 1 && xobjBar.nTop <= this.nBottom && xobjBar.nBottom >= this.nTop && xobjBar.nRightSide == this.nLeftSide) {
        xobjBar.nRightDir = -1;
        bReturn = true;
    }

    // collide with right side
    else if (xobjBar.nRightDir == -1 && xobjBar.nTop <= this.nBottom && xobjBar.nBottom >= this.nTop && xobjBar.nLeftSide == this.nRightSide) {
        xobjBar.nRightDir = 1;
        bReturn = true;
    }

    return bReturn;
}

//------ end Bar class
