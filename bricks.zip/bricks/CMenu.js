﻿function CMenu() {
    this.nScore = 0;
    this.nLives = 3;
    this.objContext = null;
    this.nLivesWidth = 0;
    this.nScoreWidth = 0;

    this.strLabelLives = "Lives Remaining :";
    this.strLabelScore = "Score :";

    this.nLabelBuffer = 2;

    this.nLabelLivesX = 5;
    this.nLabelScoreX = 250;
    this.nTextY = 8;

    this.objFont = "bold 12px sans-serif";
    this.nTextHeight = 10;
}

CMenu.prototype.constructor = CMenu;

CMenu.prototype.init = function () {
    this.objContext.font = this.objFont;
    this.objContext.textBaseline = "top";

    this.nLivesWidth = this.objContext.measureText(this.strLabelLives).width;
    this.objContext.fillText(this.strLabelLives, this.nLabelLivesX, this.nTextY);

    this.nScoreWidth = this.objContext.measureText(this.strLabelScore).width;
    this.objContext.fillText(this.strLabelScore, this.nLabelScoreX, this.nTextY);

    this.draw();
};

CMenu.prototype.draw = function () {
    this.objContext.font = this.objFont;
    this.objContext.textBaseline = "top";

    var objMetrics = this.objContext.measureText(nLives);
    this.objContext.clearRect(this.nLabelLivesX + this.nLabelBuffer + this.nLivesWidth, this.nTextY, objMetrics.width, this.nTextHeight);
    this.objContext.fillText(nLives, this.nLabelLivesX + this.nLabelBuffer + this.nLivesWidth, this.nTextY);

    objMetrics = this.objContext.measureText(nScore);
    this.objContext.clearRect(this.nLabelScoreX + this.nLabelBuffer + this.nScoreWidth, this.nTextY, objMetrics.width, this.nTextHeight);
    this.objContext.fillText(nScore, this.nLabelScoreX + this.nLabelBuffer + this.nScoreWidth, this.nTextY);
};
