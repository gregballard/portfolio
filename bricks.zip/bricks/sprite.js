﻿// -------- Sprite class
// base class for all game objects.

function CSprite() {
    this.x = 0;
    this.y = 0;
}




