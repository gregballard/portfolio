import java.io.*;
import java.util.StringTokenizer;


public class HttpRequestParser {
	
	public static final String METHOD_GET = "GET";
	public static final String METHOD_HEAD = "HEAD";
	
	private InputStream m_in;
	private String m_method = "";
	private String m_filename = "";
	private String m_version = "";
	private String m_requestLine = "";
		
	public HttpRequestParser(InputStream in ) {
		m_in = in;
	}
	
	public String getMethod() {
		return m_method;
	}
	
	public String getFileName() {
		return m_filename;
	}
	
	public String getVersion() {
		return m_version;
	}
		
	public String getRequestLine() {
		return m_requestLine;
	}
	
	public boolean parse() throws UnsupportedEncodingException {
		
		boolean parseOK = false;
		
		Reader in = new InputStreamReader(
	            new BufferedInputStream(
	             m_in
	            ),"ASCII"
	           );
	
		StringBuffer requestLine = new StringBuffer();
		int c;
		boolean step = true;
		// loop through each character until we have flagged to exit
		while (step) {
			
			try {
				c = in.read();			
			
				// end if we have reached the end of the stream
				if (c == -1) {
					step = false;
				}
				
				// end if we have reached carriage return or newline
				else if (c == '\r' || c == '\n') {
					step = false;
				}
				
				// append the character to the request
				else {
					requestLine.append((char) c);
				}
				
			} catch (IOException e) {
			    step = false;  // end while if we have an exception
			}
		}	
		
		m_requestLine = requestLine.toString();
		
		if (m_requestLine != null  && !m_requestLine.isEmpty()) {
			      
			
			StringTokenizer st = new StringTokenizer(m_requestLine);
	        m_method = st.nextToken();        
	        
	        m_filename = st.nextToken();	        
	        
	        if (st.hasMoreTokens()) {
	          m_version = st.nextToken();
	        } 
	       
	        parseOK = true;  
          
		}
        return parseOK;
	}
	
}
