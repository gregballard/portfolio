import java.io.*;

public class HttpError implements IHttpProcessor {
  
    protected int m_code;
    protected String m_detail;
  
  public HttpError (int code, String detail) {   
    m_code = code;
    m_detail = detail;    
  }

  public void processRequest (HttpOutputStream out) throws IOException {
    out.setCode (m_code);
    out.setHeader ("Content-Type", "text/html");
    if (out.sendHeaders ()) {
      String msg = HttpStatus.getCodeMessage (m_code);
      out.write ("<HTML><HEAD><TITLE>" + m_code + " " +
                 msg + "</TITLE></HEAD>\n" + "<BODY><H1>" + msg + "</H1>\n" +
                 m_detail + "<P>\n</BODY></HTML>\n");
    }
  }
}
