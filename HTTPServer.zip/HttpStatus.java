
public class HttpStatus {
	public static final int OK = 200;
	public static final int NO_CONTENT = 204;
	public static final int MOVED_PERMANENTLY = 301;
	public static final int MOVED_TEMPORARILY = 302;
	public static final int BAD_REQUEST = 400;
	public static final int FORBIDDEN = 403;
	public static final int NOT_FOUND = 404;
	public static final int NOT_ALLOWED = 405;
	public static final int INTERNAL_ERROR = 500;
	public static final int NOT_IMPLEMENTED = 501;

	public static String getCodeMessage (int code) {
	  switch (code) {
	    case OK: return "OK";
	    case NO_CONTENT: return "No Content";
	    case MOVED_PERMANENTLY: return "Moved Permanently";
	    case MOVED_TEMPORARILY: return "Moved Temporarily";
	    case BAD_REQUEST: return "Bad Request";
	    case FORBIDDEN: return "Forbidden";
	    case NOT_FOUND: return "Not Found";
	    case NOT_ALLOWED: return "Method Not Allowed";
	    case INTERNAL_ERROR: return "Internal Server Error";
	    case NOT_IMPLEMENTED: return "Not Implemented";
	    default: return "Unknown Code (" + code + ")";
	  }
	}
}
