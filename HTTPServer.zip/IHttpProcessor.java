import java.io.*;

public interface IHttpProcessor {
  public void processRequest (HttpOutputStream out) throws IOException;
}
