import java.io.*;

public class GetMethodProcessor implements IHttpProcessor {
	
	private HttpRequestParser m_requestParser = null;
	private String m_indexFileName = "index.html";
	private File m_documentRootDirectory = null;
	
	public GetMethodProcessor (HttpRequestParser requestParser, String indexFile, File documentRootDirectory) {
		m_indexFileName = indexFile;		
		m_requestParser = requestParser;
		m_documentRootDirectory = documentRootDirectory;
	}
	
	public void processRequest(HttpOutputStream out) throws FileNotFoundException, IOException {		
		String filename = m_requestParser.getFileName();
        if (filename.endsWith("/")) filename += m_indexFileName;
        String contentType = guessContentTypeFromName(filename);
        
        File theFile = new File(m_documentRootDirectory, filename.substring(1,filename.length()));
        if (theFile.canRead() 
            // Don't let clients outside the document root
         && theFile.getCanonicalPath().startsWith(m_documentRootDirectory.getPath())) {      	  
        
          out.setHeader ("Content-type", contentType);
          out.setHeader ("Content-length", String.valueOf (theFile.length ()));
          
          if (out.sendHeaders ()) {
            FileInputStream in = new FileInputStream (theFile);
            out.write (in);
            in.close ();
          }
                    
          out.flush();
        }  // end if

        else {  // can't find the file
        	HttpError error = new HttpError(HttpStatus.NOT_FOUND, "File Not Found");
        	error.processRequest(out);        	
        } 
	}

	
	 public static String guessContentTypeFromName(String name) {
		    if (name.endsWith(".html") || name.endsWith(".htm")) {
		      return "text/html";
		    }
		    else if (name.endsWith(".txt") || name.endsWith(".java")) {
		      return "text/plain";
		    }
		    else if (name.endsWith(".gif")) {
		      return "image/gif";
		    }
		    else if (name.endsWith(".class")) {
		      return "application/octet-stream";
		    }
		    else if (name.endsWith(".jpg") || name.endsWith(".jpeg")) {
		      return "image/jpeg";
		    }
		    else return "text/plain";
		  }
}
