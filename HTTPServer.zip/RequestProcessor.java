import java.net.*;
import java.io.*;
import java.util.*; 
public class RequestProcessor implements Runnable {  
	
  private static List<Socket> pool = new LinkedList<Socket>();
  private File documentRootDirectory;
  private String indexFileName = "index.html";
  
  public RequestProcessor(File documentRootDirectory, 
   String indexFileName) {        
    if (documentRootDirectory.isFile()) {
      throw new IllegalArgumentException(
       "documentRootDirectory must be a directory, not a file");   
    }
    this.documentRootDirectory = documentRootDirectory;
    try {
      this.documentRootDirectory 
       = documentRootDirectory.getCanonicalFile();
    }
    catch (IOException e) {
    }
    if (indexFileName != null) this.indexFileName = indexFileName;
  }
  
  public static void processRequest(Socket request) {
    
    synchronized (pool) {
      pool.add(pool.size(), request);
      pool.notifyAll();
    }
  } 

public void run() { 
        
    while (true) {       
      Socket connection;
      synchronized (pool) {         
        while (pool.isEmpty()) {
          try {
            pool.wait();
          }
          catch (InterruptedException e) {
          }
        }
        connection = (Socket) pool.remove(0); 
      }
      try {               	  
    	  
         
        OutputStream raw = new BufferedOutputStream(
                            connection.getOutputStream()
                           );                
        
        HttpRequestParser requestParser = new HttpRequestParser(connection.getInputStream());
        
        // determine which HTTPProcessor implementation should be used
        IHttpProcessor processor = getProcessor(requestParser);
        
        processor.processRequest(new HttpOutputStream(raw, requestParser));        
    
      }

      catch (IOException e) {
      }
      
      finally {
        try {
          connection.close();        
        }
        catch (IOException e) {} 
      }      
    } // end while
  } // end run

  private IHttpProcessor getProcessor (HttpRequestParser requestParser) throws UnsupportedEncodingException {
	  
    IHttpProcessor processor = null;
    if (requestParser.parse()) {  // make sure the request is ok
    
		// log the request 
		System.out.println(requestParser.getRequestLine());	        
        
        if (requestParser.getMethod().equals(HttpRequestParser.METHOD_GET)) {
        	processor = new GetMethodProcessor(requestParser, indexFileName, documentRootDirectory);
        	
        	
        }
        else {  // method does not equal "GET"
        	
        	processor = new HttpError(HttpStatus.NOT_FOUND, "Not Implemented");
        	
        }
    }
    
    else {
    	processor = new HttpError(HttpStatus.BAD_REQUEST, "Bad Request");
    	/*protected void parseVersion (String verStr) throws HttpException {
		    if (!verStr.startsWith ("HTTP/"))
		      throw new HttpException (HTTP.STATUS_BAD_REQUEST, verStr);
		    try {
		      version = Float.valueOf (verStr.substring (5)).floatValue ();
		    } catch (NumberFormatException ex) {
		      throw new HttpException (HTTP.STATUS_BAD_REQUEST, verStr);
		    }
		  }
		  */
    }
    
    return processor;
  }
/*
  protected HttpProcessor getProcessor (HttpInputStream httpIn) {
	    try {
	      httpIn.readRequest ();
	      if (httpIn.getPath ().startsWith (HTTP.CGI_BIN))
	        return new HttpCGI (httpIn, client.getInetAddress ());
	      else if (httpIn.getPath ().startsWith (HTTP.CLASS_BIN))
	        return new HttpClass (httpIn);
	      else
	        return new HttpFile (httpIn);
	    } catch (HttpException ex) {
	      return ex;
	    } catch (Exception ex) {
	      StringWriter trace = new StringWriter ();
	      ex.printStackTrace (new PrintWriter (trace, true));
	      return new HttpException (HTTP.STATUS_INTERNAL_ERROR,
	                                "<PRE>" + trace + "</PRE>");
	    }
	  }
	*/  




} // end RequestProcessor