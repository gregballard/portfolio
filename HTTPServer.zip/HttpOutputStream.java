// modified from HttpOutputStream

import java.io.*;
import java.util.*;

public class HttpOutputStream extends BufferedOutputStream {
	
  public static final String SERVER_INFO = "JHTTP 1.0";
  protected int code;
  protected boolean sendHeaders, sendBody;
  protected Hashtable<String, String> headers = new Hashtable<String, String> ();

  public HttpOutputStream (OutputStream out, HttpRequestParser requestParser) {
    super (out);
    code = HttpStatus.OK;
    setHeader ("Server", SERVER_INFO);
    setHeader ("Date", new Date ().toString ());
    sendHeaders = requestParser.getVersion().startsWith("HTTP/"); //(in.getVersion () >= 1.0);
    sendBody = !HttpRequestParser.METHOD_HEAD.equals (requestParser.getMethod ());
  }

  public void setCode (int code) {
    this.code = code;
  }

  public void setHeader (String attr, String value) {
    headers.put (attr, value);
  }

  public boolean sendHeaders () throws IOException {
    if (sendHeaders) {
      write ("HTTP/1.0 " + code + " " + HttpStatus.getCodeMessage (code) + "\r\n");
      Enumeration<String> attrs = headers.keys ();
      while (attrs.hasMoreElements ()) {
        String attr = (String) attrs.nextElement ();
        write (attr + ": " + headers.get (attr) + "\r\n");
      }
      write ('\n');
    }
    return sendBody;
  }

  public void write (String msg) throws IOException {
    write (msg.getBytes ("latin1"));
  }

  public void write (InputStream in) throws IOException {
    int n, length = buf.length;
    while ((n = in.read (buf, count, length - count)) >= 0)
      if ((count += n) >= length)
        out.write (buf, count = 0, length);
  }
}

