package csc574;

public class ActionResult {

	public static final String STATUS_NOT_SET = "NOT_SET";
	public static final String STATUS_SUCCESS = "SUCCESS";
	public static final String STATUS_FAIL = "FAIL";
	
	private String m_strStatus = STATUS_NOT_SET;
	
	private String m_strMessage = "";
	
	public String getMessage() {
		return m_strMessage;
	}
	
	public void setMessage(String xstrMessage) {
		m_strMessage = xstrMessage;
	}
	
	public String getStatus() {
		return m_strStatus;
	}
	
	public void setResultStatus(String xstrStatus) {
		m_strStatus = xstrStatus;
	}
}
