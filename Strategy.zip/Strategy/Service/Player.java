package csc574;

public class Player {
	protected int m_nCoins = 0;
	protected Game m_objGame = null;
	
	public int getCoins() {
		return m_nCoins;
	}
	
	public void setCoins(int xnCoins) {
		m_nCoins = xnCoins;
	}
	
	public void adjustCoins(int xnCoins) {
		m_nCoins += xnCoins;
	}
			
}
