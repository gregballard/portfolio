package csc574;

public class CombatEngine {	
	
	public static CombatResult combat(int xnDefendingTroops, int xnAttackingTroops) {
		
		CombatResult result = new CombatResult();
		
		if (xnDefendingTroops > xnAttackingTroops) {
			result.setResult(CombatResult.enumResult.DEFENSE);
		}
		
		else if (xnDefendingTroops < xnAttackingTroops) {
			result.setResult(CombatResult.enumResult.CONQUER);
		}
		
		// if attacking troops == defending troops, default to draw
		
		return result;
	}
}

