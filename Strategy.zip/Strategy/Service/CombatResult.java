package csc574;

public class CombatResult {
	
	public enum enumResult { DRAW, DEFENSE, CONQUER };
	
	private enumResult m_enumResult = enumResult.DRAW;
	private String m_strMessage = "";
	
	public void setMessage(String xstrMessage) {
		m_strMessage = xstrMessage;		
	}
	
	public String getMessage() {
		return m_strMessage;
	}
	
	public void setResult (enumResult xenumResult) {
		m_enumResult = xenumResult;
	}
	
	public enumResult getResult() {
		return m_enumResult;
	}
}