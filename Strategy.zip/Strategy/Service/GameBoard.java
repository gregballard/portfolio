package csc574;

import java.util.ArrayList;

public class GameBoard {
	private Cell m_objBoard [][];
	
	public GameBoard(){};
	
	public GameBoard(int xnWidth, int xnHeight, int xnStartTroops) {
		
		m_objBoard = new Cell[xnHeight][xnWidth];
		
		int i;
		int j;
		
		for (i = 0; i < xnHeight; i++) {
			
			for (j = 0; j < xnWidth; j++) {
				m_objBoard[i][j] = new Cell();
				m_objBoard[i][j].setCoords(j, i);				
									
			}
		}
		
		m_objBoard[0][0].setOwner(Game.PLAYER_COMPUTER);
		m_objBoard[0][0].setTroopCount(xnStartTroops);
		
		m_objBoard[xnHeight - 1][xnWidth - 1].setOwner(Game.PLAYER_PLAYER1);
		m_objBoard[xnHeight - 1][xnWidth - 1].setTroopCount(xnStartTroops);
	}
	
	public Cell[][] getAllCells() {
		return m_objBoard;
	}
	
	public Cell getCell(int xnXCoord, int xnYCoord) {
		return m_objBoard[xnYCoord][xnXCoord];
	}
	
	public int getWidth() {
		return m_objBoard[0].length;
	}
	
	public int getHeight() {
		return m_objBoard.length;
	}

	public int getCellCount(String xstrOwner) {
		
		int nCellCount = 0;
		
		int i = 0;
		int j = 0;
		for (i = 0; i < getWidth(); i++) {
			for (j = 0; j < getHeight(); j++) {
				if (m_objBoard[i][j].getOwner().equals(xstrOwner)) {
					nCellCount++;
				}
			}
		}
		
		return nCellCount;
	}
	
	public ArrayList<Cell> getAdjacentCells(Cell xobjCell) {
		ArrayList<Cell> arrayOfCells = new ArrayList<Cell>();
		
		int nXAdj = -1;
		int nYAdj = -1;
		
		int i = 0;
		int j = 0;
		
		for (i = -1; i <= 1; i++) {
			for (j = -1; j <= 1; j++) {				
				
				nXAdj = xobjCell.getXCoord() + i;
				nYAdj = xobjCell.getYCoord() + j;
				
				// make sure potential adj cell is on the board
				if (nXAdj >= 0 && nXAdj < getWidth() && nYAdj >= 0 && nYAdj < getHeight() ) {
					arrayOfCells.add(getCell(nXAdj, nYAdj));
				}				
			}
		}
		
		return arrayOfCells;
		
	}
}
