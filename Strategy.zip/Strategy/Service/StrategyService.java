/*******
 * The project will be to design and implement a set of web services to provide the back-end functionality for a 
 *  multi-player turn based strategy game. The web services developed using Java.  For the initial version, there
 *  will be a single computer controlled second player.  The design should allow for multiple computer players 
 *  and eventually human players to be added to the game. The service operations will consist of a "startGame", 
 *  "doAction", and "endGame".  The "startGame" service call will generate a 10x10 grid as the game board.  
 *  Each player is located at one of the corners of the board.  With each turn, coins will be generated for 
 *  each point in the grid each player controls.  Actions will consist of "Move" and "Recruit" commands.  Move 
 *  sends existing troops to an adjacent location.  Recruit will spend coins to place new troops at points 
 *  controlled by the purchasing player.  The "endGame" service call will shut down the game and release server 
 *  resources.  Alternately, the game will shutdown on it's own if no requests are received within a set amount 
 *  of time.  The winner is the first player to eliminate all opposing troops.
 */

package csc574;
import java.util.HashMap;

import javax.jws.WebService;
import javax.jws.WebMethod;

@WebService
public class StrategyService {
	
	private static HashMap<Integer, Game> games = new HashMap<Integer, Game>();
	
	@WebMethod
	public int startGame() {
	  	Game newGame = new Game(10,10);
	  	
	  	int count = -1;
	  	
	  	synchronized(games) {
	  		count = games.size();
	  		while (games.containsKey(count)) {
	  			count++;
	  		}
	  			
	  		games.put(count, newGame);	  
	  	}
	  	
	  	return count;
	}
	
	@WebMethod
	public GameBoard getBoard(int xnKey) {
		Game game = getGame(xnKey);
		GameBoard board = game.getBoard();
		return board;
	}
	
	private Game getGame(int xnKey) {
		Game game = games.get(xnKey);
		return game;
	}
		
	@WebMethod
	public Cell getCell(int xnKey, int xnXCoord, int xnYCoord) {		
	    return getGame(xnKey).getBoard().getCell(xnXCoord, xnYCoord);
	}
	
	@WebMethod
	public int endGame(int xnGameKey) {
	 
		int nReturn = 1;
		
		synchronized (games) {
			games.remove(xnGameKey);
			nReturn = 0;
		}
	
		return nReturn;
	}
	
	@WebMethod
	public Player getPlayer(int xnKey, String xstrPlayer) {
		return getGame(xnKey).getPlayer(xstrPlayer);	
	}
	
	@WebMethod
	public ActionResult recruit(int xnKey, String xstrPlayer, int xnRecruitCount, int xnXCoord, int xnYCoord) {
		return getGame(xnKey).recruitTroops(xstrPlayer, xnRecruitCount, xnXCoord, xnYCoord);
	}
	
	@WebMethod
	public ActionResult move(int xnKey, String xstrPlayer, int xnXCoordStart, int xnYCoordStart, int xnXCoordEnd, int xnYCoordEnd, int xnTroops) {
		return getGame(xnKey).Move(xstrPlayer, xnXCoordStart, xnYCoordStart, xnXCoordEnd, xnYCoordEnd, xnTroops);
	}
	
	@WebMethod
	public String getStatus(int xnKey) {		
		return getGame(xnKey).getStatus().toString();
	}
		
}
