package csc574;

public class Game {

	public enum enumStatus { TURN_PLAYER, TURN_COMPUTER, GAME_OVER_COMPUTER_WIN, GAME_OVER_PLAYER_WIN, GAME_OVER_DRAW};
	public final static String PLAYER_NONE = "None";
	public final static String PLAYER_COMPUTER = "Computer";
	public final static String PLAYER_PLAYER1 = "Player1";
	public final static int DEFAULT_BOARD_WIDTH = 10;
	public final static int DEFAULT_BOARD_HEIGHT = 10;
	public final static int START_TROOPS = 5;
	public final static int START_COINS = 5;
	
	private enumStatus m_enumStatus = enumStatus.TURN_PLAYER;  // player starts turn
	
	private GameBoard m_objBoard = null;
	private Player m_objPlayer = new Player();
	private AIPlayer m_objAIPlayer = new AIPlayer();
	
	public Game () {
		this(DEFAULT_BOARD_WIDTH, DEFAULT_BOARD_HEIGHT)	;	
	}
	
	public Game (int nWidth, int nHeight) {
		m_objBoard = new GameBoard(nWidth, nHeight, START_TROOPS);		

		m_enumStatus = enumStatus.TURN_PLAYER;
		m_objPlayer.setCoins(START_COINS);
		m_objAIPlayer.setCoins(START_COINS);		
	}
	
	public GameBoard getBoard() {
		return m_objBoard;
	}	
	
	public ActionResult Move(String xstrPlayer, int xnStartX, int xnStartY,  int xnEndX, int xnEndY, int xnTroops) {
		Cell cellStart = m_objBoard.getCell(xnStartX, xnStartY);
		Cell cellEnd = m_objBoard.getCell(xnEndX, xnEndY);
		
		return Move(xstrPlayer, cellStart, cellEnd, xnTroops);		
	}
	
	public ActionResult Move(String xstrPlayer, Cell xobjCellStart, Cell xobjCellEnd, int xnTroops) {
		
		ActionResult result = new ActionResult();
		result.setResultStatus(ActionResult.STATUS_FAIL);  // assume failure		
		
		// check the cells are next to each other 
		int nXDiff = Math.abs(xobjCellStart.getXCoord() - xobjCellEnd.getXCoord());
		int nYDiff = Math.abs(xobjCellStart.getYCoord() - xobjCellEnd.getYCoord());
		
		if ( (nXDiff == 1 && nYDiff <= 1) || (nXDiff <= 1 && nYDiff == 1)) {
			
			// check there are enough troops in the cell to move
			if (xobjCellStart.getTroopCount() >= xnTroops) {
				
				// OK to move
				result.setResultStatus(ActionResult.STATUS_SUCCESS);
				xobjCellStart.adjustTroops(-xnTroops);	
				
				// determine combat
				String targetOwner = xobjCellEnd.getOwner(); 
				if ( !targetOwner.equals(xstrPlayer) && !targetOwner.equals(Game.PLAYER_NONE) ) {
					// combat
					/*CombatResult combatResult = */xobjCellEnd.combat(xstrPlayer, xnTroops);				
					result.setMessage("Combat!!!");
				}
				
				else { // move successful									
					xobjCellEnd.adjustTroops(xnTroops);		
					xobjCellEnd.setOwner(xstrPlayer);
					result.setMessage("Move successful.");
				}
				
				endTurn();
				
			}
			
			else {
				result.setMessage("Attempting to move more troops than available.");
			}
		}
		
		else {  // not adjacent cells
			result.setMessage("Cells must be adjacent to move troops.");
		}
		
		return result;	
	
	}
	
	public ActionResult recruitTroops(String xstrPlayer, int xnRecruitCount, int xnCellX, int xnCellY) {
		
		ActionResult result = new ActionResult();
		result.setResultStatus(ActionResult.STATUS_FAIL);  // assume failure
		
		Player objPlayer = getPlayer(xstrPlayer);
		
		// check the player has enough coins for recruitment
		int nCoinsAvailable = objPlayer.getCoins();
		
		if (nCoinsAvailable < xnRecruitCount) {
			result.setMessage("Not enough coins for recruitment.");
		}
		
		else {  // make sure the cell belongs to the recruiting player
			Cell objCell = m_objBoard.getCell(xnCellX,  xnCellY);
			
			if (!objCell.getOwner().equals(xstrPlayer)) {
				result.setMessage("You must own this cell to recruit troops.");
			}
			else {
				objCell.adjustTroops(xnRecruitCount);
				objPlayer.adjustCoins(0 - xnRecruitCount);
				result.setResultStatus(ActionResult.STATUS_SUCCESS);
			}
		}
		
		return result;
	}
	
	public void endTurn() {
		int nComputerCells = m_objBoard.getCellCount(Game.PLAYER_COMPUTER);
		int nPlayerCells = m_objBoard.getCellCount(Game.PLAYER_PLAYER1);
		
		if (nComputerCells <= 0 && nPlayerCells <= 0) {
			m_enumStatus = enumStatus.GAME_OVER_DRAW;
		}
		
		if (nComputerCells <= 0) {
			m_enumStatus = enumStatus.GAME_OVER_PLAYER_WIN;
		}
	
		else if (nPlayerCells <= 0) {
			m_enumStatus = enumStatus.GAME_OVER_COMPUTER_WIN;
		}
		
		else if (m_enumStatus == enumStatus.TURN_COMPUTER) {
			m_objPlayer.adjustCoins(nPlayerCells);
			m_enumStatus = enumStatus.TURN_PLAYER;
		}
		
		else {
			m_objAIPlayer.adjustCoins(nComputerCells);
			m_enumStatus = enumStatus.TURN_COMPUTER;
		}
		
		// if the computers turn, process now.
		if (m_enumStatus == enumStatus.TURN_COMPUTER) {
			m_objAIPlayer.processTurn(this);
		}
	}
	
	public Player getPlayer(String xstrPlayer) {
		
		Player returnPlayer = null;
		
		if (xstrPlayer.equals(PLAYER_COMPUTER)) {
			returnPlayer = m_objAIPlayer;
		}
		
		else if (xstrPlayer.equals(PLAYER_PLAYER1)) {
			returnPlayer = m_objPlayer;
		}

		return returnPlayer;

	}
	
	public enumStatus getStatus() {
		return m_enumStatus;
	}
}
