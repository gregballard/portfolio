package csc574;

import java.util.ArrayList;

public class AIPlayer extends Player {

	private GameBoard m_objBoard = null;
	private Game m_objGame = null;
	
	public AIPlayer() {		
	}
	
	public void processTurn(Game xobjGame) {
		m_objGame = xobjGame;
		m_objBoard = xobjGame.getBoard();
		
		// recruit troops
		recruitment();
		
		// move troops
		movement();	
		
	}
	
	private void recruitment() {
		// if more than 5 coins, recruit troops and place on a cell with the smallest troop count.
		if (m_nCoins > 5) {
			
			int nCellX = 0;
			int nCellY = 0;
			
			int nMinCount = 0;
			
			int i = 0;
			int j = 0;
			
			for (i = 0; i < m_objBoard.getWidth(); i++) {
				for (j = 0; j < m_objBoard.getHeight(); j++) {
					Cell objCell = m_objBoard.getCell(i, j); 
					if (objCell.getOwner().equals(Game.PLAYER_COMPUTER)) {
						
						if (nMinCount == 0) {
							nMinCount = objCell.getTroopCount();
						}
						
						else if (objCell.getTroopCount() <= nMinCount) {
							nMinCount = objCell.getTroopCount();
							nCellX = i;
							nCellY = j;
						}
					}
				}
			}			
			
			m_objGame.recruitTroops(Game.PLAYER_COMPUTER, m_nCoins, nCellX, nCellY);
		}
	}
	
	private void movement() {
		// if more than 4 troops in a cell, then Move to cell in this order:
		// unoccupied first
		// opponent occupied if can win or draw,
		// otherwise, no move.
		
		int i = 0;
		int j = 0;
		boolean bMoved = false;
		
		for (i = 0; i < m_objBoard.getWidth() && !bMoved; i++) {
			for (j = 0; j < m_objBoard.getHeight() && !bMoved; j++) {
				Cell objCell = m_objBoard.getCell(i, j); 
				if (objCell.getOwner().equals(Game.PLAYER_COMPUTER)) {
					
					if (objCell.getTroopCount() > 4) {
					  
					  
					  ArrayList<Cell> arrayOfCells = m_objBoard.getAdjacentCells(objCell);
					  
					  int k = 0;
					  for (k = 0; k < arrayOfCells.size() && !bMoved; k++) {
						  if (arrayOfCells.get(k).getOwner().equals(Game.PLAYER_NONE)) {
							  bMoved = true;
							  m_objGame.Move(Game.PLAYER_COMPUTER, objCell , arrayOfCells.get(k), objCell.getTroopCount() - 1); // leave one troop
						  }
					  }
					  
					  if (!bMoved) { // check for player occupation
						  int l = 0;
						  for (l = 0; l < arrayOfCells.size() && !bMoved; l++) {
							  if (arrayOfCells.get(l).getOwner().equals(Game.PLAYER_PLAYER1)) {
								  
								  // check to see if moving troops will result in win or draw
								  // easy to check now, as combat engine expands, may need to run trial combat through it.
								  if ((objCell.getTroopCount() - 1) >= arrayOfCells.get(l).getTroopCount()) {								  
								  
								      bMoved = true;
								      m_objGame.Move(Game.PLAYER_COMPUTER, objCell , arrayOfCells.get(l), objCell.getTroopCount() - 1); // leave one troop
								  }
							  }
						  }						    						  
					  }
					  
					}									
				}
			}
		}			
	}
}
