package csc574;

public class Cell {  

  private String m_strOwner = Game.PLAYER_NONE;  
  private int m_nTroopCount = 0;
  private int m_nXCoord = -1;
  private int m_nYCoord = -1;
  
  public Cell() {
	  m_strOwner = Game.PLAYER_NONE;
  }
  
  public void setCoords(int xnXCoord, int xnYCoord) {
	  m_nXCoord = xnXCoord;
	  m_nYCoord = xnYCoord;
  }
  
  public int getXCoord() {
	  return m_nXCoord;	  
  }
  
  public int getYCoord() {
	  return m_nYCoord;
  }
  
  public void setOwner(String xstrOwner) {
	  m_strOwner = xstrOwner;
  }
  
  public String getOwner() {
	  return m_strOwner;
  }
  
  public void setTroopCount(int xnTroopCount) {
	  m_nTroopCount = xnTroopCount;
  }
  
  public int getTroopCount() {
	  return m_nTroopCount;
  }
  
  // can be + or - troops
  public void adjustTroops(int xnTroopCount) {
	  
	  m_nTroopCount += xnTroopCount;
	    
	  if (m_nTroopCount < 1) {
		  m_strOwner = Game.PLAYER_NONE;
		}
  }
  
  public CombatResult combat(String xstrAttackingPlayer, int xnAttackingTroops) {	  
		
	  CombatResult combatResult = CombatEngine.combat(m_nTroopCount, xnAttackingTroops);
	  
	  m_nTroopCount = Math.abs(m_nTroopCount - xnAttackingTroops);
	  
	  if (combatResult.getResult() == CombatResult.enumResult.CONQUER) {
		  m_strOwner = xstrAttackingPlayer;
	  }
	  
	  else if (combatResult.getResult() == CombatResult.enumResult.DRAW) {
		  m_strOwner = Game.PLAYER_NONE;
	  }
	  
	  return combatResult;
  }
  
}
